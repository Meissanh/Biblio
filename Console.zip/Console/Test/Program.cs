﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Biblio;

namespace Test
{
    public class Program
    {
        public static SourceDonnees sourceDonnees;
        public static void Main(string[] args)
        {
            bool i = true;
            string choix;
            sourceDonnees = new SourceDonnees();
            while (i == true)
            {
                Console.WriteLine("\nSélectionnez l'action que vous souhaitez effectuer : ");
                Console.WriteLine(" 1 - Afficher les utilisateurs");
                Console.WriteLine(" 2 - Afficher la liste des livres");
                Console.WriteLine(" 3 - Afficher les emprunts en cours");
                Console.WriteLine(" 4 - Ajouter un nouvel utilisateur");
                Console.WriteLine(" 5 - Ajouter un nouveau livre");
                Console.WriteLine(" 6 - Emprunter un livre");
                Console.WriteLine(" 7 - Retourner un livre");
                Console.WriteLine(" 8 - Quitter l'application");

                choix = Console.ReadLine();
                switch (choix)
                {
                    case "1":
                        AfficherUtilisateurs();
                        break;

                    case "2":
                        AfficherLivres();
                        break;

                    case "3":
                        AfficherEmpruntsEnCours();
                        break;

                    case "4":
                        AjtUtilisateur();
                        break;

                    case "5":
                        AjtLivre();
                        break;

                    case "6":
                        AjtEmprunt();
                        break;

                    case "7":
                        RetournerLivre();
                        break;

                    case "8": 
                        i = false;
                        Console.Clear();
                        break;

                }
            }

            

            Console.ReadKey();
        }
        public static void AfficherUtilisateurs()
        {
            Console.WriteLine("Liste des utilisateurs :");
            foreach (var utilisateur in sourceDonnees.GetUtilisateurs())
            {
                Console.WriteLine(utilisateur.ToString());
            }

        }
        public static void AfficherLivres()
        {
            Console.WriteLine("\nListe des livres :");
            foreach (var livre in sourceDonnees.GetLivres())
            {
                Console.WriteLine(livre);
            }
        }

        public static void AfficherEmpruntsEnCours()
        {
            Console.WriteLine("\nListe des emprunts en cours :");
            foreach (var emprunt in sourceDonnees.GetEmpruntsEnCours())
            {
                Console.WriteLine(emprunt.ToString());
            }
        }

        public static void AjtUtilisateur()
        {
            Console.WriteLine("\nAjouter un nouvel utilisateur :");
            Console.WriteLine("Veuillez entrer l'identifiant de l'utilisateur : ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Veuillez entrer le nom de l'utilisateur : ");
            string nom = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le prénom de l'utilisateur : ");
            string prenom = Console.ReadLine();
            sourceDonnees.AjouterUtilisateur(id, nom, prenom);
            Console.WriteLine($"L'utilisateur {nom} {prenom} a bien été ajouté ! ");
        }

        public static void AjtLivre()
        {
            Console.WriteLine("\nAjouter un nouveau livre :");
            Console.WriteLine("Veuillez entrer l'identifiant du livre : ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Veuillez entrer l'isbn associé au livre : ");
            string isbn = Console.ReadLine();
            Console.WriteLine("Veuillez entrer le titre du livre : ");
            string titre = Console.ReadLine();
            Console.WriteLine("Veuillez entrer l'auteur du livre : ");
            string auteur = Console.ReadLine();
            sourceDonnees.AjouterLivre(id, isbn, titre, auteur);
            Console.WriteLine($"Le livre a bien été ajouté ! ");
        }

        public static void AjtEmprunt()
        {
            Console.WriteLine("Veuillez entrer l'isbn associé au livre : ");
            List<Livre> livres = sourceDonnees.GetLivresEmpruntables();
            string isbn = Console.ReadLine();
            int i = 0;
            while (i < livres.Count - 1 && !isbn.Equals(livres[i].Isbn))
            {
                i++;
            }

            if (i < livres.Count && livres[i].Isbn.Equals(isbn))
            {
                Console.WriteLine("\nVeuillez maintenant entrer vos informations personnelles :");
                Console.WriteLine("Votre identifiant : ");
                int idutilisateur = int.Parse(Console.ReadLine());
                Console.WriteLine("Votre nom : ");
                string nom = Console.ReadLine();
                Console.WriteLine("Votre prénom : ");
                string prenom = Console.ReadLine();
                Utilisateur unUtilisateur = new Utilisateur(idutilisateur, nom, prenom);
                sourceDonnees.AjouterEmprunt(unUtilisateur, livres[i], DateTime.Now);
                Console.WriteLine("Le livre a bien été emprunté");

            }

            else
            {
                Console.WriteLine("L'isbn entré n'est pas correct ");
            }
        }

        public static void LivresEmpruntables()
        {
            Console.WriteLine("Liste des livres empruntables :");
            foreach (var livre in sourceDonnees.GetLivresEmpruntables())
            {
                Console.WriteLine(livre.ToString());
            }
        }

        public static void RetournerLivre()
        {

            Console.WriteLine("Veuillez entrer l'isbn associé au livre que vous souhaitez retourner : ");
            List<Livre> livres = sourceDonnees.GetLivresEmpruntables();
            string isbn = Console.ReadLine();
            int i = 0;
            while (i < livres.Count - 1 && !isbn.Equals(livres[i].Isbn))
            {
                i++;
            }

            if (i < livres.Count && livres[i].Isbn.Equals(isbn))
            {
                string prenom = Console.ReadLine();
                Emprunt unEmprunt = new Emprunt(emprunteur,livres)
                sourceDonnees.EnregistrerRetour()
                Console.WriteLine("Le livre a bien été retourné");

            }

            else
            {
                Console.WriteLine("L'isbn entré n'est pas correct ");
            }
        }
    }
    }
}
