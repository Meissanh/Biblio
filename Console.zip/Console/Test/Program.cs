﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblio;

namespace Test
{
    internal class Program
    {
        static void Main(string[] args)
        {
                SourceDonnees sourceDonnees = new SourceDonnees();

                Console.WriteLine("Liste des utilisateurs :");
                foreach (var utilisateur in sourceDonnees.GetUtilisateurs())
                {
                    Console.WriteLine(utilisateur.ToString());
                }

                Console.WriteLine("\nListe des livres :");
                foreach (var livre in sourceDonnees.GetLivres())
                {
                    Console.WriteLine(livre);
                }

                Console.WriteLine("\nListe des emprunts en cours :");
                foreach (var emprunt in sourceDonnees.GetEmpruntsEnCours())
                {
                    Console.WriteLine(emprunt.ToString());
                }
                Console.ReadKey();
        }
    }
}
