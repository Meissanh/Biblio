﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblio
{
    public class Emprunt
    {
        DateTime date;
        bool rendu;

        Utilisateur emprunteur;
        Livre livre;

        public DateTime Date { get => date; set => date = value; }
        public bool Rendu { get => rendu; set => rendu = value; }
        public Utilisateur Emprunteur { get => emprunteur; set => emprunteur = value; }
        public Livre Livre { get => livre; set => livre = value; }


        public Emprunt(Utilisateur emprunteur, Livre livre)
        {
            this.Emprunteur = emprunteur;
            this.Livre = livre;
            rendu = false;
        }

        public override string ToString()
        {
            return "Livre : " + livre.Titre + " Emprunté par : " + emprunteur.Nom + " " + emprunteur.Prenom + " Date d'emprunt : " + date.ToString("dd/mm/yyyy");
        }
    }
}
