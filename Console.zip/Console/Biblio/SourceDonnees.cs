﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblio
{
    public class SourceDonnees
    {
        List<Emprunt> emprunts;
        List<Livre> livres;
        List<Utilisateur> utilisateurs;

        public SourceDonnees()
        {
            utilisateurs = new List<Utilisateur>();
            utilisateurs.Add(new Utilisateur(1, "Neymar", "Jean"));
            utilisateurs.Add(new Utilisateur(2, "Bou", "Carrie"));
            utilisateurs.Add(new Utilisateur(13, "Morokundi", "Frank"));

            livres = new List<Livre>();
            livres.Add(new Livre(1, "978-2070368228", "1994 ", "Georges Booles"));
            livres.Add(new Livre(2, "978-2078368228", "1988 ", "matudi"));
            livres.Add(new Livre(1, "978-2074368228", "2001 ", "francois"));
            livres.Add(new Livre(1, "978-2070368328", "2024 ", "Georges blt"));

            emprunts = new List<Emprunt>();
            Emprunt emprunt = new Emprunt(utilisateurs[0], livres[1]);
            emprunt.Rendu = true;
            emprunts.Add(emprunt);
            emprunt = new Emprunt(utilisateurs[0], livres[2]);
            emprunts.Add(emprunt);
            emprunt = new Emprunt(utilisateurs[2], livres[1]);
            emprunts.Add(emprunt);
        }

        public void AjouterEmprunt(Utilisateur unUtilisateur, Livre unLivre, DateTime dateActuelle)
        {
            emprunts.Add(new Emprunt(unUtilisateur, unLivre));
        }

        public void AjouterLivre(int unId, string unISBN, string unTitre, string unAuteur)
        {
            livres.Add(new Livre(unId, unISBN, unTitre, unAuteur));
        }

        public void AjouterUtilisateur(int unId, string unNom, string unPrenom)
        {
            utilisateurs.Add(new Utilisateur(unId, unNom, unPrenom));
        }

        public void EnregistrerRetour(Emprunt unEmprunt)
        {
            unEmprunt.Rendu = true;
        }

        public List<Emprunt> GetEmpruntsEnCours()
        {
            List<Emprunt> empruntsactuels = new List<Emprunt>();
            foreach(Emprunt unEmprunt in emprunts)
            {
                if (unEmprunt.Rendu == false)
                {
                    empruntsactuels.Add(unEmprunt);
                }
            }
            return empruntsactuels;
        }

        public List<Livre> GetLivres() 
        { 
            return livres; 
        }

        public List<Livre> GetLivresEmpruntables()
        {
            List<Livre> dispo = new List<Livre>();
            List<Emprunt> enCours = GetEmpruntsEnCours();
            foreach (Livre unLivre in livres)
            {
                int i = 0;
                while (i<enCours.Count && enCours[i].Livre != unLivre)
                
                {

                    i++;
                    
                }
                if (i<enCours.Count && unLivre == enCours[i].Livre)
                {
                    dispo.Add(unLivre);
                }

            }
            return dispo;
        }

        public List<Utilisateur> GetUtilisateurs()
        {
            return utilisateurs;
        }

    }
}
