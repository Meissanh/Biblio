﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Biblio;

namespace Console
{
    internal class test
    {
        static void Main(string[] args)
        {
            
            
            
        }
    }
}
